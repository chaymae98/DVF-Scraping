from django.shortcuts import render
import requests
from django.shortcuts import render
from django.http import HttpResponse
from django.core.paginator import Paginator
from django.db.models import Avg
from .forms import Filter

# Create your views here.
'''def list_dvf(request):
    data = requests.get("http://api.cquest.org/dvf?section=94068000CQ").json()
    paginator = Paginator(data['resultats'], 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'index.html', {'page_obj': page_obj})
'''
def list_houses(request):
    api = "http://api.cquest.org/dvf?"
    val = request.POST
    for k, v in val.items():
        if v and not k == "csrfmiddlewaretoken":
            print(k)
            api=f"{api}{k}={v}&"
    print(api)
    apiUrl = f"http://api.cquest.org/dvf?code_commune=89304"
    data = requests.get(api).json()
    if not data.get("erreur"):
        paginator = Paginator(data['resultats'], 50000000000)
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        return render(request, "index2.html", {'page_obj': page_obj,'form':val.dict()})
    return render(request, "index2.html")

